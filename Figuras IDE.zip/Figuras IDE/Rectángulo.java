package figuras;
import java.awt.Color;
/**
 * Clase que representa un rectángulo.
 */
public class Rectángulo extends Figura{
private double base;
private double altura;

    /**
     * Color del rectángulo.
     * @param x coordenada X del rectángulo
     * @param y coordenada Y del rectángulo
     * @param color color del rectangulo
     * @param base base del rectámgulo
     * @param altura altura del rectángulo
     */
    public Rectángulo (double x, double y, Color color, double base, double altura){
super (x, y, color);this.base = base;this.altura = altura;
}
public double getBase(){return base;}
public double getAltura(){return altura;}
public void setBase(double base){this.base = base;}
public void setAltura(double altura){this.altura = altura;}
public double perímetro (){return 2 * base + 2 * altura;}
public double área (){return base * altura;}
}