package figuras;
import java.awt.Color;
/**
 * Clase que representa un cuadrado.
 * Es un tipo de rectángulo con todos los lados iguales.
 */
public class Cuadrado extends Rectángulo{
public Cuadrado (double x, double y, Color color, double lado) {
super (x, y, color, lado, lado);
}
}
